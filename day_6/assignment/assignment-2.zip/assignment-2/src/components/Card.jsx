const Card = () => {
  return (
    <div>Card</div>
  )
}

export default Card