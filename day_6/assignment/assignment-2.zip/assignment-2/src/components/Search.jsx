import React from "react";

const Search = () => {
  return (
    <>
      <div>
        <input type="text" placeholder="Search" />
      </div>
      <nav>
        All Music ....
      </nav>
    </>
  );
};

export default Search;
